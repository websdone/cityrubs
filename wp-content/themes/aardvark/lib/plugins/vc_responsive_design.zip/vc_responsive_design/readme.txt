Change logs:

=================================
Version 2.3.2 • Oct 3, 2017
=================================
1. Fixed: Save data

=================================
Version 2.3 • Sep 12, 2017
=================================
1. Fixed: Background image
2. Added: Category for shortcode

=================================
Version 2.2.1 • Aug 29, 2017
=================================
1. Fixed: style for Visual Composer 4.x

=================================
Version 2.2 • Aug 23, 2017
=================================
1. Fixed: save empty value
2. Fixed: problem spacing in value

=================================
Version 2.1.7 • Aug 8, 2017
=================================
1. Fixed: Style of tab item.

=================================
Version 2.1.6 • July 10, 2017
=================================
1. Fixed: Create Responsive shortcode in Inner Row

=================================
Version 2.1.5 • Apr 27, 2017
=================================
1. Fixed: Filter without logged

=================================
Version 2.1.4 • Mar 31, 2017
=================================
1. Fixed: Priority of devices

=================================
Version 2.1.3 • Mar 2, 2017
=================================
1. Fixed: Show on Admin panel

=================================
Version 2.1.2 • February 5, 2017
=================================
1. Inherited for each properties
2. Update option by each elements
3. Update documentation

=================================
Version 2.1.1 • January 28, 2017
=================================
1. Fixed javascript bug

=================================
Version 2.1 • January 25, 2017
=================================
1. Show/Hide option on any devices

=================================
Version 2.0 • January 24, 2017
=================================
1. Responsive color
2. Responsive line-height
3. Responsive letter-spacing
4. Responsive word-spacing
5. Responsive font-size
6. Responsive font-weight
7. Responsive font-style
8. Responsive white-space
9. Responsive text-overflow
10. Responsive text-align
11. Responsive text-transform
12. Responsive text-decoration

=================================
Version 1.0 • January 19, 2017
=================================
Release plugin.
1. Responsive Margin
2. Responsive Padding
3. Responsive Border Color
4. Responsive Border Size
5. Responsive Border Style
6. Responsive Border Radius
7. Responsive Background Color
8. Responsive Background Image
9. Responsive Background Size
10. UNLIMITED DEVICES
